import xbmcaddon

MainBase = 'http://bit.ly/HOMENEWW9'
addon = xbmcaddon.Addon('plugin.video.Rising.Tides')